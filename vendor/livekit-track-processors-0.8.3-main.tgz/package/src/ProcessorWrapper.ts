import { type ProcessorOptions, type Track, type TrackProcessor } from 'livekit-client';
import { type FrameTicker, createFrameTicker } from './FrameTicker';
import { TrackTransformer, TrackTransformerDestroyOptions } from './transformers';
import { createCanvas, waitForTrackResolution } from './utils';
import { LoggerNames, getLogger } from './logger';

type ProcessorWrapperLifecycleState = 'idle' | 'initializing' | 'running' | 'media-exhausted' | 'destroying' | 'destroyed';

export interface ProcessorWrapperOptions {
  /**
   * Maximum frame rate for fallback canvas.captureStream implementation.
   * Must be a positive finite number.
   * Default: 30
   */
  maxFps?: number;
}

export default class ProcessorWrapper<
  TransformerOptions extends Record<string, unknown>,
  Transformer extends TrackTransformer<TransformerOptions> = TrackTransformer<TransformerOptions>,
>
  implements TrackProcessor<Track.Kind>
{
  /**
   * Determines if the Processor is supported on the current browser
   */
  static get isSupported() {
    // Check for primary implementation support
    const hasStreamProcessor =
      typeof MediaStreamTrackGenerator !== 'undefined' &&
      typeof MediaStreamTrackProcessor !== 'undefined';

    // Check for fallback implementation support
    const hasFallbackSupport =
      typeof HTMLCanvasElement !== 'undefined' &&
      typeof VideoFrame !== 'undefined' &&
      'captureStream' in HTMLCanvasElement.prototype;

    // We can work if either implementation is available
    return hasStreamProcessor || hasFallbackSupport;
  }

  /**
   * Determines if modern browser APIs are supported, which yield better performance
   */
  static get hasModernApiSupport() {
    return (
      typeof MediaStreamTrackGenerator !== 'undefined' &&
      typeof MediaStreamTrackProcessor !== 'undefined'
    );
  }

  name: string;

  source?: MediaStreamVideoTrack;

  processor?: MediaStreamTrackProcessor<VideoFrame>;

  trackGenerator?: MediaStreamTrackGenerator<VideoFrame>;

  canvas?: OffscreenCanvas | HTMLCanvasElement;

  displayCanvas?: HTMLCanvasElement;

  sourceDummy?: HTMLMediaElement;

  processedTrack?: MediaStreamTrack;

  transformer: Transformer;

  // For tracking whether we're using the stream API fallback
  private useStreamFallback = false;

  // For fallback rendering with canvas.captureStream()
  private capturedStream?: MediaStream;

  private frameTicker?: FrameTicker;

  private renderContext?: CanvasRenderingContext2D;

  private frameCallback?: (frame: VideoFrame) => void;

  private processingEnabled = false;

  // FPS control for fallback implementation
  private maxFps: number;

  private log = getLogger(LoggerNames.ProcessorWrapper);

  private lifecycleState: ProcessorWrapperLifecycleState = 'idle';

  constructor(
    transformer: Transformer,
    name: string,
    options: ProcessorWrapperOptions = {},
  ) {
    this.name = name;
    this.transformer = transformer;
    this.maxFps = options.maxFps ?? 30;

    if (!Number.isFinite(this.maxFps) || this.maxFps <= 0) {
      throw new RangeError(`maxFps must be a positive number, got ${this.maxFps}`);
    }
  }

  private async setup(opts: ProcessorOptions<Track.Kind>) {
    this.source = opts.track as MediaStreamVideoTrack;

    const { width, height } = await waitForTrackResolution(this.source);
    this.sourceDummy = opts.element;

    if (!(this.sourceDummy instanceof HTMLVideoElement)) {
      throw TypeError('Currently only video transformers are supported');
    }

    if (this.sourceDummy instanceof HTMLVideoElement) {
      this.sourceDummy.height = height ?? 300;
      this.sourceDummy.width = width ?? 300;
    }

    this.useStreamFallback = !ProcessorWrapper.hasModernApiSupport;

    if (this.useStreamFallback) {
      // Create a visible canvas for the fallback implementation or use an existing one if provided
      const existingCanvas = document.querySelector(
        'canvas[data-livekit-processor="' + this.name + '"]',
      ) as HTMLCanvasElement;

      if (existingCanvas) {
        this.displayCanvas = existingCanvas;
        this.displayCanvas.width = width ?? 300;
        this.displayCanvas.height = height ?? 300;
      } else {
        this.displayCanvas = document.createElement('canvas');
        this.displayCanvas.width = width ?? 300;
        this.displayCanvas.height = height ?? 300;
        this.displayCanvas.style.display = 'none';
        this.displayCanvas.dataset.livekitProcessor = this.name;
        document.body.appendChild(this.displayCanvas);
      }

      this.renderContext = this.displayCanvas.getContext('2d')!;
      this.capturedStream = this.displayCanvas.captureStream();
      this.canvas = createCanvas(width ?? 300, height ?? 300);
    } else {
      // Use MediaStreamTrackProcessor API
      this.processor = new MediaStreamTrackProcessor({ track: this.source });
      this.trackGenerator = new MediaStreamTrackGenerator({
        kind: 'video',
        signalTarget: this.source,
      });
      this.canvas = createCanvas(width ?? 300, height ?? 300);
    }
  }

  async init(opts: ProcessorOptions<Track.Kind>): Promise<void> {
    this.log.debug('Init called');
    this.lifecycleState = 'initializing';
    await this.setup(opts);

    if (!this.canvas) {
      throw new TypeError('Expected canvas to be defined after setup');
    }

    await this.transformer.init({
      outputCanvas: this.canvas,
      inputElement: this.sourceDummy as HTMLVideoElement,
    });

    if (this.useStreamFallback) {
      this.initFallbackPath();
    } else {
      this.initStreamProcessorPath();
    }
    this.lifecycleState = 'running';
  }

  private initStreamProcessorPath() {
    if (!this.processor || !this.trackGenerator) {
      throw new TypeError(
        'Expected processor and trackGenerator to be defined for stream processor path',
      );
    }

    const readableStream = this.processor.readable;
    const pipedStream = readableStream.pipeThrough(this.transformer!.transformer!);

    pipedStream
      .pipeTo(this.trackGenerator.writable)
      // if stream finishes, the media to process is exhausted
      .then(() => this.handleMediaExhausted())
      // destroy processor if stream errors - unless it's an abort error
      .catch((e) => {
        if (e instanceof DOMException && e.name === 'AbortError') {
          this.log.log('stream processor path aborted');
        } else if (e instanceof DOMException && e.name === 'InvalidStateError' && e.message === 'Stream closed') {
          this.log.log('stream processor underlying stream closed');
          this.handleMediaExhausted();
        } else {
          this.log.error('error when trying to pipe', e);
          this.destroy();
        }
      });

    this.processedTrack = this.trackGenerator as MediaStreamVideoTrack;
  }

  private initFallbackPath() {
    if (!this.capturedStream || !this.source || !this.canvas || !this.renderContext) {
      throw new TypeError('Missing required components for fallback implementation');
    }

    this.processedTrack = this.capturedStream.getVideoTracks()[0];
    this.processingEnabled = true;

    // Set up the frame callback for the transformer
    this.frameCallback = (frame: VideoFrame) => {
      if (!this.processingEnabled || !frame) {
        frame.close();
        return;
      }

      const controller = {
        enqueue: (processedFrame: VideoFrame) => {
          if (this.renderContext && this.displayCanvas) {
            // Follow the video element, not the frame: both track rotation, but on iOS frames keep the
            // unrotated sensor size (640x480 for a 480x640 track) and the published track must match the track.
            const { videoWidth, videoHeight } = this.sourceDummy as HTMLVideoElement;
            if (
              videoWidth &&
              videoHeight &&
              (this.displayCanvas.width !== videoWidth || this.displayCanvas.height !== videoHeight)
            ) {
              this.displayCanvas.width = videoWidth;
              this.displayCanvas.height = videoHeight;
            }
            // Draw the processed frame to the visible canvas
            this.renderContext.drawImage(
              processedFrame,
              0,
              0,
              this.displayCanvas.width,
              this.displayCanvas.height,
            );
            processedFrame.close();
          }
        },
      } as TransformStreamDefaultController<VideoFrame>;

      try {
        // Pass the frame through our transformer
        // @ts-ignore - The controller expects both VideoFrame & AudioData but we're only using VideoFrame
        this.transformer.transform(frame, controller);
      } catch (e) {
        this.log.error('Error in transform:', e);
        frame.close();
      }
    };

    // Start the rendering loop
    this.startRenderLoop();
  }

  private startRenderLoop() {
    if (!this.sourceDummy || !(this.sourceDummy instanceof HTMLVideoElement)) {
      this.handleMediaExhausted();
      return;
    }

    // Store the last processed timestamp to avoid duplicate processing
    let lastVideoTimestamp = -1;
    let nextFrameDue = performance.now();
    const videoElement = this.sourceDummy as HTMLVideoElement;
    const minFrameInterval = 1000 / this.maxFps; // Minimum time between frames

    // Estimate the video's native frame rate
    let estimatedVideoFps = this.maxFps;
    let frameTimeHistory: number[] = [];
    let lastVideoTimeChange = 0;
    let frameCount = 0;
    let lastFpsLog = 0;
    let lastPlayAttempt = -Infinity; // first paused tick retries right away

    const renderFrame = () => {
      if (
        !this.processingEnabled ||
        !this.sourceDummy ||
        !(this.sourceDummy instanceof HTMLVideoElement)
      ) {
        this.handleMediaExhausted();
        return;
      }

      if (this.sourceDummy.paused) {
        // play() can be refused (NotAllowedError on WebKit outside a user gesture); re-arming only from its
        // .then() (#121) ended the loop for good on rejection. Re-arm every frame instead, like the
        // no-new-frame path, and retry play() once a second.
        if (performance.now() - lastPlayAttempt > 1000) {
          lastPlayAttempt = performance.now();
          this.log.warn('Video is paused, trying to play');
          this.sourceDummy.play().catch((e) => this.log.warn('Unable to play video', e));
        }
        return;
      }

      // Only process a new frame if the video has actually updated
      const videoTime = videoElement.currentTime;
      const now = performance.now();

      // Detect if video has a new frame
      const hasNewFrame = videoTime !== lastVideoTimestamp;

      // Update frame rate estimation if we have a new frame
      if (hasNewFrame) {
        if (lastVideoTimeChange > 0) {
          const timeBetweenFrames = now - lastVideoTimeChange;
          frameTimeHistory.push(timeBetweenFrames);

          // Keep a rolling window of the last 10 frame times
          if (frameTimeHistory.length > 10) {
            frameTimeHistory.shift();
          }

          // Calculate average frame interval
          if (frameTimeHistory.length > 2) {
            const avgFrameTime =
              frameTimeHistory.reduce((sum, time) => sum + time, 0) / frameTimeHistory.length;
            estimatedVideoFps = 1000 / avgFrameTime;

            // Log estimated FPS every 5 seconds in development environments
            // Use a simpler check that works in browsers without process.env
            const isDevelopment =
              (typeof window !== 'undefined' && window.location.hostname === 'localhost') ||
              window.location.hostname === '127.0.0.1';

            if (isDevelopment && now - lastFpsLog > 5000) {
              this.log.debug(
                `[${this.name}] Estimated video FPS: ${estimatedVideoFps.toFixed(
                  1,
                )}, Processing at: ${(frameCount / 5).toFixed(1)} FPS`,
              );
              frameCount = 0;
              lastFpsLog = now;
            }
          }
        }
        lastVideoTimeChange = now;
      }

      // Determine if we should process this frame
      // We'll process if:
      // 1. The video has a new frame
      // 2. The next frame is due (respecting maxFps)
      if (hasNewFrame && now >= nextFrameDue) {
        lastVideoTimestamp = videoTime;
        // Advancing the deadline rather than restarting it from now keeps the output at maxFps
        // instead of at the tick the sampler happens to land on; clamping stops a stalled loop
        // from bursting to catch up.
        nextFrameDue = Math.max(now, nextFrameDue + minFrameInterval);
        frameCount++;

        try {
          // Create a VideoFrame from the video element
          if (videoElement.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA) {
            const frame = new VideoFrame(videoElement);
            if (this.frameCallback) {
              this.frameCallback(frame);
            } else {
              frame.close();
            }
          }
        } catch (e) {
          this.log.error('Error in render loop:', e);
        }
      }
    };

    // The ticker samples the source; the frame deadline above is what caps the output at maxFps.
    // Sampling at twice maxFps keeps every deadline reachable without publishing more frames.
    this.frameTicker = createFrameTicker(1000 / (this.maxFps * 2), renderFrame);
  }

  async restart(opts: ProcessorOptions<Track.Kind>): Promise<void> {
    this.log.debug('Restart called');
    await this.destroy({ willProcessorRestart: true });
    await this.init(opts);
  }

  async restartTransformer(...options: Parameters<(typeof this.transformer)['restart']>) {
    // @ts-ignore unclear why the restart method only accepts VideoTransformerInitOptions instead of either those or AudioTransformerInitOptions
    await this.transformer.restart(options[0]);
  }

  async updateTransformerOptions(...options: Parameters<(typeof this.transformer)['update']>) {
    await this.transformer.update(options[0]);
  }

  /** Called if the media pipeline no longer can read frames to process from the source media */
  private async handleMediaExhausted() {
    this.log.debug('Media was exhausted from source');
    if (this.lifecycleState !== 'running') {
      return;
    }
    this.lifecycleState = 'media-exhausted'
    await this.cleanup();
  }

  /** Tears down the media stack logic initialized in initStreamProcessorPath / initFallbackPath */
  private async cleanup() {
    if (this.useStreamFallback) {
      this.processingEnabled = false;
      this.frameTicker?.stop();
      this.frameTicker = undefined;
      if (this.displayCanvas && this.displayCanvas.parentNode) {
        this.displayCanvas.parentNode.removeChild(this.displayCanvas);
      }
      this.capturedStream?.getTracks().forEach((track) => track.stop());
    } else {
      // NOTE: closing writableControl below terminates the stream in initStreamProcessorPath /
      // calls the .then(...) which calls this.handleMediaExhausted
      await this.processor?.writableControl?.close();
      this.trackGenerator?.stop();
    }
  }

  async destroy(transformerDestroyOptions: TrackTransformerDestroyOptions = { willProcessorRestart: false }) {
    this.log.debug(`Destroy called - lifecycleState=${this.lifecycleState}, transformerDestroyOptions=${JSON.stringify(transformerDestroyOptions)}`);
    switch (this.lifecycleState) {
      case 'running':
      case 'media-exhausted':
        this.lifecycleState = 'destroying';

        await this.cleanup();

        await this.transformer.destroy(transformerDestroyOptions);
        this.lifecycleState = 'destroyed';
        break;

      default:
        break;
    }
  }
}
