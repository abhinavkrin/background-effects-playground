# LiveKit track processors

Prebuilt audio and video track processors for [LiveKit](https://livekit.io), implementing the [`TrackProcessor`](https://docs.livekit.io/reference/client-sdk-js/interfaces/TrackProcessor.html) interface from `livekit-client`.

## Install

```
npm add @livekit/track-processors
```

## Video processors

Video track processors intercept a local video track's frames and transform them before they are sent to other participants. This package provides a prebuilt `BackgroundProcessor` that supports background blur and virtual backgrounds:

```ts
import { BackgroundProcessor } from '@livekit/track-processors';

const processor = BackgroundProcessor({ mode: 'background-blur', blurRadius: 10 });
await videoTrack.setProcessor(processor);
```

Available modes: `background-blur`, `virtual-background`, and `disabled` (passthrough).

See [processor-docs/video-processors.md](processor-docs/video-processors.md) for full usage, browser support checks, and how to avoid visual artifacts when switching modes.

## Audio processors

Audio track processors work similarly — they intercept the local audio track and pipe it through a Web Audio API processing graph before publishing. The included `GainAudioProcessor` provides gain control and serves as a reference implementation for building custom audio processors:

```ts
import { GainAudioProcessor } from '@livekit/track-processors';

const processor = new GainAudioProcessor({ gainValue: 1.5 });
await audioTrack.setProcessor(processor);
```

See [processor-docs/audio-processors.md](processor-docs/audio-processors.md) for full usage, the `TrackProcessor` interface for audio, and a guide to building your own audio processor with the Web Audio API.

## Developing your own processors

This package implements the `TrackProcessor` interface from `livekit-client`. Video and audio processors take different approaches:

- **Video processors** use `ProcessorWrapper` with a transformer pipeline — see [processor-docs/video-processors.md](processor-docs/video-processors.md#developing-your-own-video-processor)
- **Audio processors** implement `TrackProcessor` directly using the Web Audio API — see [processor-docs/audio-processors.md](processor-docs/audio-processors.md#building-your-own-audio-processor)

## Running the sample app

This repository includes a small example app at `examples/demo`, built on [Vite](https://vitejs.dev/), that demonstrates both video and audio processors. It connects to a LiveKit room, so you'll need a server URL and a token. Run it with:

```
# install pnpm: https://pnpm.io/installation
pnpm install
pnpm sample
```

## Running the e2e harness app

`examples/e2e` is a second app used by the end-to-end test suite. It needs no LiveKit server and no webcam: it mocks `getUserMedia` with a deterministic, procedurally composited video source, and exposes measurement APIs on `window.harness`. Run it with:

```
pnpm dev:e2e
```

It's also the quickest way to reproduce a rendering bug across browsers by hand — see [examples/e2e/README.md](examples/e2e/README.md) for the query parameters and the API.

## Running the end-to-end tests

```
pnpm test:e2e           # headless
pnpm test:e2e:headed    # watch it in a real browser window
```

Uses your installed Google Chrome and needs no server, webcam or launch flags. See
[e2e/README.md](e2e/README.md) for the other run modes and what's covered.
