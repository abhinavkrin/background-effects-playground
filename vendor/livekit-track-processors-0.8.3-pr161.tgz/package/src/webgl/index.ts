/**
 * WebGL setup for the mask processor
 * potential improvements:
 * - downsample the video texture in background blur scenario before applying the (gaussian) blur for better performance
 *
 */
import { getLogger, LoggerNames} from '../logger';
import { applyBlur, createBlurProgram } from './shader-programs/blurShader';
import { createBoxBlurProgram } from './shader-programs/boxBlurShader';
import { createCompositeProgram } from './shader-programs/compositeShader';
import { applyDownsampling, createDownSampler } from './shader-programs/downSampler';
import { createEdgeRefinementProgram } from './shader-programs/edgeRefinementShader';
import { createTemporalMaskProgram } from './shader-programs/temporalMaskShader';
import {
  createFramebuffer,
  createVertexBuffer,
  getEmptyImageData,
  initTexture,
  resizeImageToCover,
  resizeTexture,
} from './utils';

const log = getLogger(LoggerNames.WebGl);

/**
 * How a segmentation mask is blended into the frame.
 * - `binary`: the mask is 1 for the background and 0 for the person. It is feathered and cut at
 *   0.5, so every pixel away from the edge is fully the frame or fully the background.
 * - `alpha`: the mask is the person's opacity, 1 for the person and 0 for the background. It is
 *   lightly feathered and the frame is blended over the background by that value.
 */
export type MaskBlending = 'binary' | 'alpha';

/** `[low, high]`: the alpha that becomes fully background and the one that becomes fully person. */
export type AlphaRange = [low: number, high: number];

/** The full range: the alpha is the opacity as it is. */
export const DEFAULT_ALPHA_RANGE: AlphaRange = [0, 1];

export const DEFAULT_EDGE_REFINEMENT_RADIUS = 4;

export const setupWebGL = (canvas: OffscreenCanvas | HTMLCanvasElement) => {
  const gl = canvas.getContext('webgl2', {
    // Every pass is a full-screen quad, so multisampling only adds a resolve per frame.
    antialias: false,
    premultipliedAlpha: true,
  }) as WebGL2RenderingContext;

  let blurRadius: number | null = null;
  let maskBlurRadius: number | null = 8;
  let alphaRange = DEFAULT_ALPHA_RANGE;
  // The segmenter scales its mask up to the frame in blocks, which leaves steps along the edge.
  // An alpha mask is blurred just enough to round them off: its values stay the blend opacity,
  // so a wider blur would show as a halo around the person.
  const alphaMaskBlurRadius = 4;
  const downsampleFactor = 4;
  // The segmentation mask is at most a few hundred pixels across, so feathering it at
  // full frame size only multiplies the box-blur cost. The mask buffers are kept near
  // this longest edge and the composite upsamples them with LINEAR filtering.
  const maskBufferTargetEdge = 640;
  const getMaskDownsampleFactor = (width: number, height: number) =>
    Math.max(1, Math.round(Math.max(width, height) / maskBufferTargetEdge));

  if (!gl) {
    log.error('Failed to create WebGL context');
    return undefined;
  }

  // Blending is only enabled around the composite draw: the intermediate passes all
  // write opaque output, so blending them just costs a framebuffer read.
  gl.disable(gl.BLEND);

  // Create the composite program
  const composite = createCompositeProgram(gl);
  const compositeProgram = composite.program;
  const positionLocation = composite.attribLocations.position;
  const {
    mask: maskTextureLocation,
    frame: frameTextureLocation,
    background: bgTextureLocation,
    disableBackground: disableBackgroundLocation,
    maskIsAlpha: maskIsAlphaLocation,
    maskIsBackground: maskIsBackgroundLocation,
    alphaRange: alphaRangeLocation,
  } = composite.uniformLocations;

  // Create the blur program using the same vertex shader source
  const blur = createBlurProgram(gl);
  const blurProgram = blur.program;
  const blurUniforms = blur.uniforms;

  // Create the box blur program
  const boxBlur = createBoxBlurProgram(gl);
  const boxBlurProgram = boxBlur.program;
  const boxBlurUniforms = boxBlur.uniforms;

  const temporalMask = createTemporalMaskProgram(gl);
  let temporalSmoothing = false;
  let hasMaskHistory = false;
  let edgeRefinement: ReturnType<typeof createEdgeRefinementProgram> | null = null;

  const bgTexture = initTexture(gl, 0);
  let frameTexture = initTexture(gl, 1);
  let previousFrameTexture = initTexture(gl, 8);
  let uploadedFrame: VideoFrame | null = null;
  const vertexBuffer = createVertexBuffer(gl);

  if (!vertexBuffer) {
    throw new Error('Failed to create vertex buffer');
  }

  // Create additional textures and framebuffers for processing
  let bgBlurTextures: WebGLTexture[] = [];
  let bgBlurFrameBuffers: WebGLFramebuffer[] = [];

  // For double buffering the final mask
  let finalMaskTextures: WebGLTexture[] = [];
  let readMaskIndex = 0; // Index for renderFrame to read from
  let writeMaskIndex = 1; // Index for updateMask to write to
  // How the mask in each buffer is blended, as given to the updateMask call that wrote it
  const finalMaskBlending: MaskBlending[] = ['binary', 'binary'];
  const finalMaskIsBackground = [false, false];

  // Create textures for background processing (blur)
  bgBlurTextures.push(initTexture(gl, 3)); // For blur pass 1
  bgBlurTextures.push(initTexture(gl, 4)); // For blur pass 2

  let bgBlurTextureWidth = Math.floor(canvas.width / downsampleFactor);
  let bgBlurTextureHeight = Math.floor(canvas.height / downsampleFactor);

  const downSampler = createDownSampler(gl, bgBlurTextureWidth, bgBlurTextureHeight);

  // Create framebuffers for background processing
  bgBlurFrameBuffers.push(
    createFramebuffer(gl, bgBlurTextures[0], bgBlurTextureWidth, bgBlurTextureHeight),
  );
  bgBlurFrameBuffers.push(
    createFramebuffer(gl, bgBlurTextures[1], bgBlurTextureWidth, bgBlurTextureHeight),
  );

  let maskDownsampleFactor = getMaskDownsampleFactor(canvas.width, canvas.height);
  let maskBufferWidth = Math.max(1, Math.round(canvas.width / maskDownsampleFactor));
  let maskBufferHeight = Math.max(1, Math.round(canvas.height / maskDownsampleFactor));

  // Initialize texture for the first mask blur pass
  const tempMaskTexture = initTexture(gl, 5);
  const tempMaskFrameBuffer = createFramebuffer(
    gl,
    tempMaskTexture,
    maskBufferWidth,
    maskBufferHeight,
  );

  const blurredMaskTexture = initTexture(gl, 9);
  const blurredMaskFrameBuffer = createFramebuffer(
    gl,
    blurredMaskTexture,
    maskBufferWidth,
    maskBufferHeight,
  );

  const refinedMaskTexture = initTexture(gl, 10);
  const refinedMaskFrameBuffer = createFramebuffer(
    gl,
    refinedMaskTexture,
    maskBufferWidth,
    maskBufferHeight,
  );

  // Initialize two textures for double-buffering the final mask
  finalMaskTextures.push(initTexture(gl, 6)); // For reading in renderFrame
  finalMaskTextures.push(initTexture(gl, 7)); // For writing in updateMask

  // Create framebuffers for the final mask textures
  const finalMaskFrameBuffers = [
    createFramebuffer(gl, finalMaskTextures[0], maskBufferWidth, maskBufferHeight),
    createFramebuffer(gl, finalMaskTextures[1], maskBufferWidth, maskBufferHeight),
  ];

  // Store custom background image, cropped to cover the canvas, and the source it was cropped from
  let customBackgroundImage: ImageBitmap | ImageData | null = null;
  let backgroundSourceImage: ImageBitmap | null = null;

  // The transformer sets the canvas to each frame's display size, which drifts from the size the buffers
  // were allocated at (device rotation, iOS reporting the unrotated sensor size). Called from updateMask
  // and renderFrame: whichever first sees a new size reallocates, the other only compares.
  let bufferWidth = canvas.width;
  let bufferHeight = canvas.height;

  function ensureBuffersMatchCanvas() {
    if (canvas.width === bufferWidth && canvas.height === bufferHeight) {
      return;
    }
    bufferWidth = canvas.width;
    bufferHeight = canvas.height;
    bgBlurTextureWidth = Math.floor(bufferWidth / downsampleFactor);
    bgBlurTextureHeight = Math.floor(bufferHeight / downsampleFactor);
    for (const texture of [downSampler.texture, ...bgBlurTextures]) {
      resizeTexture(gl, texture, bgBlurTextureWidth, bgBlurTextureHeight);
    }
    maskDownsampleFactor = getMaskDownsampleFactor(bufferWidth, bufferHeight);
    maskBufferWidth = Math.max(1, Math.round(bufferWidth / maskDownsampleFactor));
    maskBufferHeight = Math.max(1, Math.round(bufferHeight / maskDownsampleFactor));
    for (const texture of [
      tempMaskTexture,
      blurredMaskTexture,
      refinedMaskTexture,
      ...finalMaskTextures,
    ]) {
      resizeTexture(gl, texture, maskBufferWidth, maskBufferHeight);
    }
    hasMaskHistory = false;
    if (backgroundSourceImage) {
      // Not awaited: the image cropped for the previous size shows until the re-crop resolves.
      setBackgroundImage(backgroundSourceImage);
    }
  }

  let backgroundImageDisabled = false;

  // Set up uniforms for the composite shader
  gl.useProgram(compositeProgram);
  gl.uniform1i(disableBackgroundLocation, backgroundImageDisabled ? 1 : 0);
  gl.uniform1i(bgTextureLocation, 0);
  gl.uniform1i(frameTextureLocation, 1);
  gl.uniform1i(maskTextureLocation, 2);

  /** Uploads a frame once, whether updateMask or renderFrame sees it first. */
  function uploadFrame(frame: VideoFrame) {
    if (frame === uploadedFrame) {
      return;
    }
    uploadedFrame = frame;
    if (temporalSmoothing) {
      [frameTexture, previousFrameTexture] = [previousFrameTexture, frameTexture];
    }
    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, frameTexture);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, frame);
  }

  function renderFrame(frame: VideoFrame) {
    if (frame.codedWidth === 0 || finalMaskTextures.length === 0) {
      return;
    }

    const width = frame.displayWidth;
    const height = frame.displayHeight;

    ensureBuffersMatchCanvas();

    uploadFrame(frame);

    // The blurred frame, else the custom background, else the frame itself, which the composite passes through
    let backgroundTexture = frameTexture;

    if (blurRadius) {
      const downSampledFrameTexture = applyDownsampling(
        gl,
        frameTexture,
        downSampler,
        vertexBuffer!,
        bgBlurTextureWidth,
        bgBlurTextureHeight,
      );
      backgroundTexture = applyBlur(
        gl,
        downSampledFrameTexture,
        bgBlurTextureWidth,
        bgBlurTextureHeight,
        blurRadius,
        blurProgram,
        blurUniforms,
        vertexBuffer!,
        bgBlurFrameBuffers,
        bgBlurTextures,
      );
    } else if (customBackgroundImage) {
      // setBackgroundImage() uploads the image into bgTexture whenever it changes, and
      // nothing else writes to it, so the static background is not re-uploaded per frame.
      backgroundTexture = bgTexture;
    }

    let maskTexture = finalMaskTextures[readMaskIndex];
    if (edgeRefinement) {
      gl.useProgram(edgeRefinement.program);
      gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
      gl.vertexAttribPointer(edgeRefinement.uniforms.position, 2, gl.FLOAT, false, 0, 0);
      gl.enableVertexAttribArray(edgeRefinement.uniforms.position);
      gl.bindFramebuffer(gl.FRAMEBUFFER, refinedMaskFrameBuffer);
      gl.viewport(0, 0, maskBufferWidth, maskBufferHeight);
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, maskTexture);
      gl.uniform1i(edgeRefinement.uniforms.mask, 0);
      gl.activeTexture(gl.TEXTURE1);
      gl.bindTexture(gl.TEXTURE_2D, frameTexture);
      gl.uniform1i(edgeRefinement.uniforms.frame, 1);
      gl.drawArrays(gl.TRIANGLES, 0, 6);
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      maskTexture = refinedMaskTexture;
    }

    // Render the final composite
    gl.viewport(0, 0, width, height);
    gl.clearColor(1.0, 1.0, 1.0, 1.0);
    gl.clear(gl.COLOR_BUFFER_BIT);

    gl.useProgram(compositeProgram);
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    gl.vertexAttribPointer(positionLocation, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(positionLocation);

    // Set background texture (either original, blurred or custom)
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, backgroundTexture);
    gl.uniform1i(bgTextureLocation, 0);
    gl.uniform1i(disableBackgroundLocation, backgroundImageDisabled ? 1 : 0);

    // Set frame texture
    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, frameTexture);
    gl.uniform1i(frameTextureLocation, 1);

    gl.activeTexture(gl.TEXTURE2);
    gl.bindTexture(gl.TEXTURE_2D, maskTexture);
    gl.uniform1i(maskTextureLocation, 2);
    // The segmenter renders into this context too and can leave its own blend function set.
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.uniform1i(maskIsAlphaLocation, finalMaskBlending[readMaskIndex] === 'alpha' ? 1 : 0);
    gl.uniform1i(maskIsBackgroundLocation, finalMaskIsBackground[readMaskIndex] ? 1 : 0);
    gl.uniform2f(alphaRangeLocation, alphaRange[0], alphaRange[1]);
    gl.enable(gl.BLEND);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
    gl.disable(gl.BLEND);
  }

  /**
   * Set or update the background image
   * @param image The background image to use, or null to clear
   */
  async function setBackgroundImage(image: ImageBitmap | null) {
    backgroundSourceImage = image;

    if (!image) {
      customBackgroundImage = null;
    } else {
      // bgTexture keeps showing the current image until the new one is cropped
      let croppedImage: ImageBitmap | ImageData = getEmptyImageData();
      try {
        // Resize and crop the image to cover the canvas
        croppedImage = await resizeImageToCover(image, canvas.width, canvas.height);
      } catch (error) {
        log.error(
          'Error processing background image, falling back to black background:',
          error,
        );
      }
      // A later call or cleanup() replaced or cleared the image while it was cropping
      if (image !== backgroundSourceImage) {
        return;
      }

      customBackgroundImage = croppedImage;
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, bgTexture);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, customBackgroundImage);
    }
  }

  function setBlurRadius(radius: number | null) {
    blurRadius = radius ? Math.max(1, Math.floor(radius / downsampleFactor)) : null; // we are downsampling the blur texture, so decrease the radius here for better performance with a similar visual result
  }

  function setBackgroundDisabled(disabled: boolean) {
    backgroundImageDisabled = disabled;
  }

  function setAlphaRange(range: AlphaRange) {
    alphaRange = range;
  }

  function setTemporalSmoothing(enabled: boolean) {
    temporalSmoothing = enabled;
    hasMaskHistory = false;
  }

  /** @param radius in mask texels, or `null` to turn refinement off */
  function setEdgeRefinement(radius: number | null) {
    if (edgeRefinement) {
      gl.deleteProgram(edgeRefinement.program);
    }
    edgeRefinement =
      radius === null ? null : createEdgeRefinementProgram(gl, Math.max(1, Math.round(radius)));
  }

  /**
   * Takes the segmenter's latest mask.
   * @param alphaIsBackground for `alpha` blending, the mask is the background's opacity rather
   *   than the person's
   * @param frame the frame the mask was segmented from, which temporal smoothing needs
   */
  function updateMask(
    mask: WebGLTexture,
    blending: MaskBlending,
    alphaIsBackground = false,
    frame?: VideoFrame,
  ) {
    // Same guard as renderFrame: cleanup() empties the arrays, a late segmentation callback must not touch them.
    if (finalMaskTextures.length === 0) {
      return;
    }
    ensureBuffersMatchCanvas();

    const smoothing = temporalSmoothing && frame !== undefined;
    if (smoothing) {
      uploadFrame(frame);
    }
    const blendWithPrevious =
      smoothing &&
      hasMaskHistory &&
      finalMaskBlending[readMaskIndex] === blending &&
      finalMaskIsBackground[readMaskIndex] === alphaIsBackground;

    // Use the existing applyBlur function to apply the first blur pass
    // The second blur pass writes the final mask, or blurredMaskTexture for temporal smoothing to blend

    // Create temporary arrays for the single blur operation
    const tempFramebuffers = [
      tempMaskFrameBuffer,
      blendWithPrevious ? blurredMaskFrameBuffer : finalMaskFrameBuffers[writeMaskIndex],
    ];

    const tempTextures = [
      tempMaskTexture,
      blendWithPrevious ? blurredMaskTexture : finalMaskTextures[writeMaskIndex],
    ];

    const radius = blending === 'alpha' ? alphaMaskBlurRadius : maskBlurRadius || 1.0;

    // Apply the blur using the existing function
    applyBlur(
      gl,
      mask,
      maskBufferWidth,
      maskBufferHeight,
      // The radius is in mask-buffer texels, so scale it down with the buffer.
      Math.max(1, Math.round(radius / maskDownsampleFactor)),
      boxBlurProgram,
      boxBlurUniforms,
      vertexBuffer!,
      tempFramebuffers,
      tempTextures,
    );

    if (blendWithPrevious) {
      gl.useProgram(temporalMask.program);
      gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
      gl.vertexAttribPointer(temporalMask.uniforms.position, 2, gl.FLOAT, false, 0, 0);
      gl.enableVertexAttribArray(temporalMask.uniforms.position);
      gl.bindFramebuffer(gl.FRAMEBUFFER, finalMaskFrameBuffers[writeMaskIndex]);
      gl.viewport(0, 0, maskBufferWidth, maskBufferHeight);
      const inputs = [
        [temporalMask.uniforms.previousMask, finalMaskTextures[readMaskIndex]],
        [temporalMask.uniforms.currentMask, blurredMaskTexture],
        [temporalMask.uniforms.previousFrame, previousFrameTexture],
        [temporalMask.uniforms.currentFrame, frameTexture],
      ] as const;
      inputs.forEach(([location, texture], unit) => {
        gl.activeTexture(gl.TEXTURE0 + unit);
        gl.bindTexture(gl.TEXTURE_2D, texture);
        gl.uniform1i(location, unit);
      });
      gl.drawArrays(gl.TRIANGLES, 0, 6);
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    }
    hasMaskHistory = smoothing;
    finalMaskBlending[writeMaskIndex] = blending;
    finalMaskIsBackground[writeMaskIndex] = alphaIsBackground;

    // Swap indices for the next frame
    readMaskIndex = writeMaskIndex;
    writeMaskIndex = 1 - writeMaskIndex;
  }

  function cleanup() {
    gl.deleteProgram(compositeProgram);
    gl.deleteProgram(blurProgram);
    gl.deleteProgram(boxBlurProgram);
    if (edgeRefinement) {
      gl.deleteProgram(edgeRefinement.program);
      edgeRefinement = null;
    }
    gl.deleteTexture(refinedMaskTexture);
    gl.deleteFramebuffer(refinedMaskFrameBuffer);
    gl.deleteTexture(bgTexture);
    gl.deleteTexture(frameTexture);
    gl.deleteTexture(previousFrameTexture);
    gl.deleteProgram(temporalMask.program);
    gl.deleteTexture(blurredMaskTexture);
    gl.deleteFramebuffer(blurredMaskFrameBuffer);
    uploadedFrame = null;
    gl.deleteTexture(tempMaskTexture);
    gl.deleteFramebuffer(tempMaskFrameBuffer);

    for (const texture of bgBlurTextures) {
      gl.deleteTexture(texture);
    }
    for (const framebuffer of bgBlurFrameBuffers) {
      gl.deleteFramebuffer(framebuffer);
    }
    for (const texture of finalMaskTextures) {
      gl.deleteTexture(texture);
    }
    for (const framebuffer of finalMaskFrameBuffers) {
      gl.deleteFramebuffer(framebuffer);
    }
    gl.deleteBuffer(vertexBuffer);

    if (downSampler) {
      gl.deleteTexture(downSampler.texture);
      gl.deleteFramebuffer(downSampler.framebuffer);
      gl.deleteProgram(downSampler.program);
    }

    // Release any ImageBitmap resources
    if (customBackgroundImage) {
      if (customBackgroundImage instanceof ImageBitmap) {
        customBackgroundImage.close();
      }
      customBackgroundImage = null;
    }
    backgroundSourceImage = null;
    bgBlurTextures = [];
    bgBlurFrameBuffers = [];
    finalMaskTextures = [];
  }

  /**
   * Release the WebGL context instead of leaving it alive until the canvas is garbage
   * collected; browsers cap live contexts and drop the oldest past that.
   *
   * Kept apart from cleanup() because a lost context stays bound to its canvas: getContext()
   * on the same canvas returns it again, so this is only for a canvas that will not be reused.
   * Anything else rendering into the context (the MediaPipe segmenter shares it) must be
   * closed first. Without WEBGL_lose_context the context is left to GC.
   */
  function releaseContext() {
    gl.getExtension('WEBGL_lose_context')?.loseContext();
  }

  return {
    renderFrame,
    updateMask,
    setBackgroundImage,
    setBlurRadius,
    setBackgroundDisabled,
    setAlphaRange,
    setTemporalSmoothing,
    setEdgeRefinement,
    cleanup,
    releaseContext,
  };
};
